# cc-tool
Linux下的CC一键脚本，基于黄金眼制作

# 本脚本仅供测试使用！！不要作死！！请勿用于非法用途！！

# 如何使用
```
wget -N --no-check-certificate "https://raw.githubusercontent.com/linux-terminal/cc/master/cc.sh" && bash cc.sh
```
